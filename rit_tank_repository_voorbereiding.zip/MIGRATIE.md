# Overstappen vanaf de lokale installatie

## Eerst vaststellen

De lokale app en repository-app hebben verschillende volledige Home Assistant-identiteiten, ook bij dezelfde slug `rit_tank`. De repository-app begint daarom met een eigen gegevensmap. Alleen de repository toevoegen voert geen migratie uit.

De huidige code bewaart:

| Onderdeel | Plaats binnen de huidige app |
| --- | --- |
| Ritten, tankbeurten, instellingen, bekende plekken, diagnoselog | `/data/rit_tank.db` |
| Tankbonafbeeldingen | `/data/receipts` |
| Add-onopties zoals API-sleutels | Door Supervisor beheerde `/data/options.json` |
| Standalone-sessiesleutel | `/data/standalone_session.key` |

De Samba-map `addons/rit_tank` bevat de broncode. Dat is niet deze interne gegevensmap. CSV-export is geen volledige back-up van alle appgegevens.

## Voorbereiding

1. Noteer de geïnstalleerde versie, kilometerstand, aantallen registraties, tracker, meldingsservice en eventuele externe poort/proxy-instellingen.
2. Sluit een actieve rit af en maak een Home Assistant-back-up waarin Rit & Tank is opgenomen. Download die en bewaar indien van toepassing ook de back-upherstelsleutel buiten Home Assistant.
3. Laat de lokale installatie geïnstalleerd. Stop deze pas bij de daadwerkelijke overdracht en voorkom dat beide instanties tegelijk dezelfde tracker verwerken of meldingen sturen.

## Gegevensoverdracht: nog uit te voeren

De huidige versie heeft nog geen complete importfunctie voor een verhuizing naar een andere appidentiteit. Daarom is dit document een migratieplan, geen reeds werkende automatische migratie.

Na het vaststellen van de nieuwe appidentiteit kiezen en testen we de overdrachtsmethode. Die moet een consistente databasekopie en alle bonafbeeldingen overnemen. Bij een bestandskopie moeten schrijvende processen gestopt zijn en moet rekening worden gehouden met SQLite WAL-bestanden. De door Supervisor beheerde opties worden via de configuratie van de nieuwe app ingesteld.

De opties, poorttoewijzing en externe proxy kunnen opnieuw moeten worden ingesteld. Een Home Assistant-back-up van de oude identiteit herstelt niet vanzelf naar de nieuwe identiteit. Deel geen back-up of wachtwoorden in een openbare repository.

## Controle voor ingebruikname

- Database kan worden geopend; aantallen, kilometerstanden en recente ritten komen overeen.
- Tankbonnen en exports zijn bereikbaar.
- Tracker en meldingsservice zijn correct ingesteld; een testmelding komt binnen.
- HTTPS/PWA-adres werkt; Ingress-links gebruiken waar nodig de nieuwe identiteit. De huidige code bevat nog `/local_rit_tank`-links; deze moeten voor ingebruikname van repositorymeldingen worden aangepast en getest.
- Een proefrit en de diagnoselog werken.

Verwijder de oude installatie pas na een geslaagde overdracht en controle. Bij problemen: stop de nieuwe instantie en hervat de oude. Nieuwe gegevens die uitsluitend in de nieuwe instantie zijn ingevoerd moeten dan apart worden behouden.
