# Rit & Tank voor Home Assistant

Eigen apprepository voor Rit & Tank: rittenregistratie, tankbeurten en een iPhone-PWA.
Eerste repositoryversie: **5.0.1**, met diagnoselog.

## Status

Dit pakket is voorbereid voor publicatie. De repository is nog niet aan een GitHub-account gekoppeld of in Home Assistant getest. Achtergrond-stopdetectie wordt nog onderzocht met de diagnoselog.

## Eenmalig toevoegen

1. Publiceer de inhoud van dit pakket in een Git-repository. `repository.yaml` moet direct in de hoofdmap staan, naast de map `rit_tank`.
2. Voeg de werkelijke repository-URL toe via Instellingen → Apps / Add-ons → Appwinkel → ⋮ → Repositories.
3. Controleer op updates. Rit & Tank verschijnt onder deze repository.
4. Bij een bestaande lokale installatie: volg eerst `MIGRATIE.md`. De nieuwe installatie neemt de oude gegevens niet automatisch over.

Gebruik de URL van de repository zelf, niet een ZIP-download of een losse map. Er is nog geen definitieve repository-URL; die volgt na het koppelen van het GitHub-account.

## Updates

Nieuwe geteste versies worden gepubliceerd met een hoger versienummer in zowel `rit_tank/config.yaml` als `APP_VERSION` in `rit_tank/app.py`. Een GitHub-release of tag alleen verandert het door Home Assistant gelezen versienummer niet.

Home Assistant haalt de broncode uit de repository en bouwt de app op het eigen apparaat. Dat kan enkele minuten duren. De ondersteunde architecturen zijn amd64 en aarch64. Er is geen vooraf gebouwd containerregister nodig voor deze eerste opzet.

Werk bij buiten een actieve rit. Controleer na installatie de versie, je registraties en een testmelding. Laat de wijzigingen eerst testen voordat ze op de door Home Assistant gebruikte standaardbranch worden geplaatst.

## Ontwikkeling

Voer vanuit de hoofdmap uit:

```sh
python3 rit_tank/test_v44.py
node rit_tank/test_ui_v44.cjs
```

Deze controles zijn offline tests, geen iPhone- of Home Assistant-installatietest. Publiceer uitsluitend bronbestanden; ritgegevens, sleutels en opties horen niet in Git.

## Documentatie

- [Repository toevoegen](https://developers.home-assistant.io/docs/apps/repository/)
- [Updates installeren](https://developers.home-assistant.io/docs/apps/tutorial/#step-4-installing-the-update)
- [Appconfiguratie en gegevensopslag](https://developers.home-assistant.io/docs/apps/configuration/)
